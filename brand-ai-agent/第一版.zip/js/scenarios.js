/**
 * 交互场景定义
 * 5大类别，22个场景 — 原型中展示5个核心场景
 */
const SCENARIOS = {
  // ===== 类别1: 智能匹配 =====
  health_matching: {
    id: 'health_matching',
    name: '🏥 健康适配商品匹配',
    category: '智能匹配',
    description: '用户AI上传体质、过敏、饮食禁忌数据，品牌智能体筛选适配产品，剔除风险成分。',
    complexity: 'high',
    requirements: [
      '无花生/海鲜过敏原',
      '低糖配方',
      '适合敏感肌使用',
      '成分透明可溯源',
    ],
    constraints: [
      '必须通过皮肤科测试',
      '无人工香精',
      'pH值5.5-6.5',
    ],
    budgetLimit: 3000,
    initialMessage: '我的用户有以下需求：敏感肌适用、无致敏成分、低糖配方的日用产品。请小米品牌方提供适配方案。',
    // 品牌AI会反问的预判领域
    counterQuestionDomain: 'health',
  },

  // ===== 类别2: 价格协商 =====
  price_negotiation: {
    id: 'price_negotiation',
    name: '💰 跨平台价格智能议价',
    category: '价格协商',
    description: '用户AI提供全网比价数据，品牌智能体给出对等价格优惠及生态专属权益。',
    complexity: 'medium',
    requirements: [
      '旗舰手机，预算5000以内',
      '需要512GB存储',
      '拍照性能优先',
    ],
    constraints: [
      '京东同款4799元',
      '天猫旗舰店4899元',
      '拼多多百亿补贴4699元',
    ],
    budgetLimit: 5000,
    initialMessage: '我在全网比价后发现小米15S Pro 512GB版本：京东4799、天猫4899、拼多多4699。小米官方能否给出更有竞争力的价格？',
    counterQuestionDomain: 'budget',
  },

  // ===== 类别3: 供应链 =====
  auto_replenish: {
    id: 'auto_replenish',
    name: '🔄 固定周期自动补货',
    category: '供应链',
    description: '双方AI根据物品消耗周期，自动规划复购时间、数量，优化库存和现金流。',
    complexity: 'low',
    requirements: [
      '空气净化器滤芯每6个月更换',
      '手环表带每3个月更换',
      '自动计算最佳补货时间窗口',
    ],
    constraints: [
      '避开涨价周期',
      '合并配送节省运费',
      '提前7天提醒确认',
    ],
    budgetLimit: 1000,
    initialMessage: '我的空气净化器滤芯将在23天后到期，手环表带已使用85天接近更换周期。请规划最优补货方案。',
    counterQuestionDomain: 'lifestyle',
  },

  // ===== 类别4: 售后与生命周期 =====
  after_sales: {
    id: 'after_sales',
    name: '🛡️ 售后纠纷自动协商',
    category: '售后与生命周期',
    description: '用户AI提交产品问题证据，品牌智能体自动给出退款、补发、维修等协商方案。',
    complexity: 'medium',
    requirements: [
      '小米手表S4屏幕出现绿线',
      '购买后第45天（超过30天退换期）',
      '有完整开箱视频和使用记录',
      '非人为损坏',
    ],
    constraints: [
      '已超过30天无忧退换',
      '仍在1年保修期内',
      '用户希望换新而非维修',
    ],
    budgetLimit: 0, // 售后场景无预算
    initialMessage: '我的小米手表S4在第45天出现屏幕绿线，非人为损坏，已提供视频证据。虽然超过30天退换期，但我希望获得换新而非维修方案。',
    counterQuestionDomain: 'budget',
  },

  // ===== 类别5: 会员与权益 =====
  bundle_custom: {
    id: 'bundle_custom',
    name: '📦 套餐组合方案定制',
    category: '会员与权益',
    description: '依据用户使用场景，品牌智能体生成最优产品组合清单，包含生态联动价值。',
    complexity: 'high',
    requirements: [
      '新家装修，需要智能家居套装',
      '包含安防、清洁、环境控制',
      '预算15000以内',
      '支持米家APP统一控制',
    ],
    constraints: [
      '三室两厅120㎡',
      '需要门锁+摄像头+烟雾报警器',
      '需要扫地机器人+空气净化器',
      '总预算不超过15000',
    ],
    budgetLimit: 15000,
    initialMessage: '我新家120㎡三室两厅，需要全套小米智能家居：安防（门锁+摄像头+烟雾报警）、清洁（扫地机器人）、环境（空气净化器+温湿度计）。预算15000以内，请出最优组合方案。',
    counterQuestionDomain: 'lifestyle',
  },
};

// 场景类别映射
const SCENARIO_CATEGORIES = {
  '智能匹配': ['health_matching'],
  '价格协商': ['price_negotiation'],
  '供应链': ['auto_replenish'],
  '售后与生命周期': ['after_sales'],
  '会员与权益': ['bundle_custom'],
};

// 导出
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SCENARIOS, SCENARIO_CATEGORIES };
}
