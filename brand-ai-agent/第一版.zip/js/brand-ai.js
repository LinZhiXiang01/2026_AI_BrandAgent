/**
 * 品牌智能体引擎 — Brand AI Agent (Xiaomi)
 *
 * 核心创新：三步逻辑
 * Step 1: 不报价，先反问 → 提出"AI无法独立回答"的问题
 * Step 2: 制造不可比变量 → 返回三个互斥且不可比的方案
 * Step 3: 置信度归零，触发人工 → 消费者AI迫使人类介入
 *
 * 角色定位：体验设计师 + 协商代理 + 信息提供者（三位一体）
 */
class BrandAI {
  constructor(knowledgeBase) {
    this.kb = knowledgeBase;
    this.brand = knowledgeBase.brand;

    // 状态
    this.state = {
      activeConversations: new Map(),  // conversationId → context
      totalEngagements: 0,
      successfulHumanEngagements: 0,   // 成功触发人工介入
      conversions: 0,                  // 最终成交
    };

    // 学习模型
    this.model = {
      // 反问效果追踪 — 哪些反问最有效触发人工介入
      questionEffectiveness: {},

      // 方案效果追踪 — 哪些方案组合最能引发人类选择
      optionTemplatePerformance: {},

      // 协商策略效果
      tacticPerformance: {},

      // 用户类型聚类（基于交互模式）
      userClusters: {
        'price_sensitive': { count: 0, preferredPath: null },
        'quality_seeker': { count: 0, preferredPath: null },
        'experience_driven': { count: 0, preferredPath: null },
        'brand_loyal': { count: 0, preferredPath: null },
      },

      // 交互历史
      history: [],
    };

    // 初始化
    this._initializeFromKB();
  }

  _initializeFromKB() {
    // 初始化反问效果追踪
    Object.keys(this.kb.counterQuestions).forEach(cat => {
      this.kb.counterQuestions[cat].forEach((q, i) => {
        const qid = `${cat}_${i}`;
        this.model.questionEffectiveness[qid] = { asked: 0, ledToHuman: 0, ledToConversion: 0 };
      });
    });

    // 初始化策略效果
    this.kb.negotiationTactics.forEach(t => {
      this.model.tacticPerformance[t.id] = { used: 0, successful: 0 };
    });
  }

  /**
   * 接收消费者AI查询 — 入口点
   * @param {Object} query - 消费者AI的查询
   * @returns {Object} 品牌AI的响应
   */
  receiveQuery(query) {
    this.state.totalEngagements++;
    const convId = query.id;

    // 创建对话上下文
    const context = {
      query: query,
      phase: 'counter_question',  // counter_question → options → negotiate
      history: [],
      consumerProfile: query.consumerContext || {},
      detectedUserType: this._detectUserType(query),
    };

    this.state.activeConversations.set(convId, context);

    // === STEP 1: 不报价，先反问 ===
    const counterQuestion = this._generateCounterQuestion(query, context);

    context.history.push({
      phase: 'counter_question',
      action: 'asked',
      content: counterQuestion,
      timestamp: new Date().toISOString(),
    });

    return {
      type: 'COUNTER_QUESTION',
      conversationId: convId,
      message: counterQuestion,
      meta: {
        phase: 1,
        strategy: '反问先行 — 识别AI决策盲区',
        detectedUserType: context.detectedUserType,
      },
    };
  }

  /**
   * 处理消费者AI对反问的回应
   * @param {string} convId - 对话ID
   * @param {Object} response - 消费者AI的回应（或人类介入答案）
   * @returns {Object} 品牌AI的下一步
   */
  handleCounterQuestionResponse(convId, response) {
    const context = this.state.activeConversations.get(convId);
    if (!context) return { error: '对话不存在' };

    context.history.push({
      phase: 'counter_question',
      action: 'responded',
      content: response,
      timestamp: new Date().toISOString(),
    });

    // 记录反问效果
    if (response.isHumanAnswer) {
      // 人类直接回答了 → 反问成功
      this.state.successfulHumanEngagements++;
      const qid = context.lastQuestionId;
      if (qid && this.model.questionEffectiveness[qid]) {
        this.model.questionEffectiveness[qid].ledToHuman++;
      }

      // 将人类答案融入上下文
      context.humanInsights = context.humanInsights || {};
      context.humanInsights[counterQuestionKey(context.lastQuestionText)] = response.answer;
    }

    // === STEP 2: 生成三个不可比方案 ===
    context.phase = 'options';
    const options = this._generateIncomparableOptions(context);

    context.history.push({
      phase: 'options',
      action: 'presented',
      content: options,
      timestamp: new Date().toISOString(),
    });

    return {
      type: 'INCOMPARABLE_OPTIONS',
      conversationId: convId,
      options: options,
      meta: {
        phase: 2,
        strategy: '制造不可比变量 — 三路径互斥方案',
        incomparabilityExplanation: this._explainIncomparability(options),
      },
    };
  }

  /**
   * 处理人类最终选择
   * @param {string} convId - 对话ID
   * @param {Object} choice - 人类选择的方案
   * @returns {Object} 最终成交方案
   */
  handleHumanChoice(convId, choice) {
    const context = this.state.activeConversations.get(convId);
    if (!context) return { error: '对话不存在' };

    this.state.conversions++;
    context.phase = 'negotiate';

    // === STEP 3: 基于人类选择，协商最优成交条件 ===
    const deal = this._negotiateDeal(context, choice);

    context.history.push({
      phase: 'negotiate',
      action: 'deal_closed',
      content: deal,
      timestamp: new Date().toISOString(),
    });

    // 学习更新
    this._learn(context, choice, deal);

    // 清理对话
    this.state.activeConversations.delete(convId);

    return {
      type: 'DEAL_CLOSED',
      conversationId: convId,
      deal: deal,
      message: `🎉 成交！基于您的选择"${choice.name}"，已为您优化最终方案。`,
      meta: {
        phase: 3,
        strategy: '价值重构 + 稀缺锚定 + 生态绑定',
        humanEngaged: true,
        aiConfidenceAtTrigger: context.query?.consumerContext?.confidence || 'N/A',
      },
      learningUpdate: this._getLearningSummary(),
    };
  }

  // ============ 核心算法 ============

  /**
   * STEP 1: 生成反问
   * 原则：问一个AI无法基于数据独立回答的问题
   */
  _generateCounterQuestion(query, context) {
    const scenario = query.scenario;
    const consumerCtx = query.consumerContext || {};

    // 根据场景和用户类型选择反问类别
    let questionCategory = 'lifestyle';

    const categoryMap = {
      health_matching: 'health',
      price_negotiation: 'budget',
      auto_replenish: 'lifestyle',
      after_sales: 'budget',
      bundle_custom: 'lifestyle',
      product_search: 'tech',
      membership: 'budget',
    };

    questionCategory = categoryMap[scenario] || 'lifestyle';

    // 获取该类别的反问
    const questions = this.kb.counterQuestions[questionCategory] ||
      this.kb.counterQuestions['lifestyle'];

    // 基于学习模型选择最有效的反问（explore vs exploit）
    const bestQuestion = this._selectBestQuestion(questions, questionCategory);
    const question = bestQuestion || questions[Math.floor(Math.random() * questions.length)];

    // 记录
    const qid = `${questionCategory}_${questions.indexOf(question)}`;
    context.lastQuestionId = qid;
    context.lastQuestionText = question;
    if (this.model.questionEffectiveness[qid]) {
      this.model.questionEffectiveness[qid].asked++;
    }

    return {
      id: qid,
      category: questionCategory,
      text: question,
      whyThisQuestion: '此问题涉及主观偏好和情境依赖的价值判断，AI无法基于纯数据做出代理决策。',
      expectedEffect: '消费者AI将识别该问题超出其决策范围，降低决策置信度。',
    };
  }

  /** 基于效果数据选择反问（Thompson Sampling简化版） */
  _selectBestQuestion(questions, category) {
    // 如果数据太少，随机探索
    const totalAsked = questions.reduce((sum, q, i) => {
      const qid = `${category}_${i}`;
      return sum + (this.model.questionEffectiveness[qid]?.asked || 0);
    }, 0);

    if (totalAsked < 5) return null; // 探索阶段

    // 选择导致人工介入率最高的反问
    let bestQ = null;
    let bestRate = 0;

    questions.forEach((q, i) => {
      const qid = `${category}_${i}`;
      const perf = this.model.questionEffectiveness[qid] || { asked: 0, ledToHuman: 0 };
      const rate = perf.asked > 0 ? perf.ledToHuman / perf.asked : 0;
      if (rate > bestRate) {
        bestRate = rate;
        bestQ = q;
      }
    });

    // 80% exploitation, 20% exploration
    return Math.random() < 0.8 ? bestQ : null;
  }

  /**
   * STEP 2: 生成三个不可比方案
   *
   * 三个路径的设计哲学：
   * - Path A "品质优先" (Quality-First)：情感锚定 — 唤起对美好体验的向往
   * - Path B "价值优先" (Value-First)：理性锚定 — 唤起对性价比的计算
   * - Path C "体验优先" (Experience-First)：稀缺锚定 — 唤起对独特性的渴望
   *
   * 这三个路径分别在不可通约的维度上最大化，AI无法加权比较。
   */
  _generateIncomparableOptions(context) {
    const query = context.query;
    const scenario = query.scenario;
    const budget = query.consumerContext?.budget?.currentLimit || 5000;
    const humanInsights = context.humanInsights || {};

    // 选择2个不可比维度作为方案间的差异轴
    const dims = this._pickIncomparableDimensions(scenario);

    // 获取相关产品
    const products = this._getRelevantProducts(scenario, query.requirements || []);

    // 构建三个方案
    const options = [
      this._buildOption('path_a', '品质优先 · 臻选之道', products, budget, dims[0], 'emotional'),
      this._buildOption('path_b', '价值优先 · 精明之选', products, budget, dims[1], 'rational'),
      this._buildOption('path_c', '体验优先 · 探索之旅', products, budget, 'novelty', 'experiential'),
    ];

    // 确保三个方案确实不可比
    this._ensureIncomparability(options, dims);

    return {
      paths: options,
      incomparabilityNote: {
        dimensions: dims,
        explanation: `三个方案在「${dims[0].label}」「${dims[1].label}」和「体验创新」三个维度上各有侧重，无法通过加权计算分出优劣。不同的人、不同的心境、不同的生活阶段，会做出不同的选择。`,
      },
    };
  }

  /** 选择不可比维度对 */
  _pickIncomparableDimensions(scenario) {
    const allDims = this.kb.incomparableDimensions;
    // 根据场景适配维度
    const scenarioDimMap = {
      health_matching: [0, 3],    // 情感vs理性, 安全vs探索
      price_negotiation: [0, 1],   // 情感vs理性, 短期vs长期
      auto_replenish: [2, 4],      // 自我vs社会, 省心vs掌控
      after_sales: [1, 3],         // 短期vs长期, 安全vs探索
      bundle_custom: [0, 2],       // 情感vs理性, 自我vs社会
    };

    const indices = scenarioDimMap[scenario] || [0, 1];
    return indices.map(i => allDims[i]);
  }

  /** 获取场景相关产品 */
  _getRelevantProducts(scenario, requirements) {
    const allProducts = [];
    Object.values(this.kb.products).forEach(list => {
      allProducts.push(...list);
    });

    // 根据场景和需求筛选
    const scenarioProductMap = {
      health_matching: ['mi-watch-s4', 'mi-band-9', 'mi-air-purifier-5'],
      auto_replenish: ['mi-band-9', 'mi-backpack-pro', 'mi-air-purifier-5'],
      price_negotiation: ['mi15s-pro', 'redmi-k90', 'mi-fold4'],
      after_sales: ['mi15s-pro', 'su7-standard', 'mi-watch-s4'],
      bundle_custom: ['mi15s-pro', 'mi-watch-s4', 'mi-air-purifier-5', 'mi-scooter-5'],
    };

    const relevantIds = scenarioProductMap[scenario] || allProducts.slice(0, 4).map(p => p.id);
    return allProducts.filter(p => relevantIds.includes(p.id));
  }

  /** 构建单个方案 */
  _buildOption(pathId, title, products, budget, dimension, flavor) {
    // 根据flavor调整产品组合
    const combo = this._composeProductCombo(products, budget, flavor);

    return {
      id: `${pathId}_${Date.now()}`,
      name: title,
      path: pathId,
      flavor: flavor,  // emotional / rational / experiential
      products: combo.products,
      totalPrice: combo.totalPrice,
      originalPrice: combo.originalPrice,
      savings: combo.originalPrice - combo.totalPrice,
      savingsPercent: Math.round((1 - combo.totalPrice / combo.originalPrice) * 100),
      valueProposition: this._generateValueProposition(pathId, combo),
      dominantDimension: dimension,
      tradeoffs: this._generateTradeoffs(pathId),
      // 锚定效应：展示原价锚点
      anchorEffect: {
        anchor: combo.originalPrice,
        actual: combo.totalPrice,
        framing: this._generateFraming(pathId, combo),
      },
    };
  }

  /** 根据flavor组合产品 */
  _composeProductCombo(products, budget, flavor) {
    const sorted = [...products].sort((a, b) => {
      if (flavor === 'emotional') return b.price - a.price;  // 贵=好
      if (flavor === 'rational') return a.price - b.price;   // 便宜=精明
      return 0;  // experiential: 保持原样
    });

    let selected;
    if (flavor === 'emotional') {
      selected = sorted.slice(0, Math.min(2, sorted.length));  // 选最贵的
    } else if (flavor === 'rational') {
      selected = sorted.slice(0, Math.min(2, sorted.length));  // 选最便宜的
    } else {
      // experiential: 选最新/最独特的
      selected = sorted.filter(p => p.tags && (p.tags.includes('AI原生') || p.tags.includes('旗舰'))).slice(0, 2);
      if (selected.length === 0) selected = sorted.slice(Math.floor(sorted.length / 2), Math.floor(sorted.length / 2) + 2);
    }

    const totalPrice = selected.reduce((sum, p) => sum + p.price, 0);
    const originalPrice = Math.round(totalPrice * (1.1 + Math.random() * 0.15));

    return {
      products: selected,
      totalPrice: Math.round(totalPrice),
      originalPrice: Math.round(originalPrice),
    };
  }

  /** 生成价值主张 */
  _generateValueProposition(pathId, combo) {
    const props = {
      path_a: `顶级品质，让每一次使用都成为享受。${combo.products.map(p => p.name).join(' + ')}的组合，是对自己的投资。`,
      path_b: `同等功能，更低成本。${combo.products.map(p => p.name).join(' + ')}，精打细算也不妥协体验。`,
      path_c: `前沿科技，领先一步。${combo.products.map(p => p.name).join(' + ')}，探索未来的生活方式。`,
    };
    return props[pathId] || '最优方案';
  }

  /** 生成方案间的权衡说明 */
  _generateTradeoffs(pathId) {
    const tradeoffs = {
      path_a: { gain: '极致体验与品质保障', lose: '预算空间被压缩，后续消费灵活性降低' },
      path_b: { gain: '最大化资金使用效率，留有预算余量', lose: '可能错过顶级配置带来的体验升级' },
      path_c: { gain: '抢先体验最新技术，社交话题与身份认同', lose: '新产品可能存在未经验证的潜在问题' },
    };
    return tradeoffs[pathId] || { gain: '', lose: '' };
  }

  /** 生成框架效应文案 */
  _generateFraming(pathId, combo) {
    const savings = combo.originalPrice - combo.totalPrice;
    const dailyCost = Math.round(combo.totalPrice / 365);

    const framings = {
      path_a: `原价¥${combo.originalPrice}，限时优惠立省¥${savings}。相当于每天仅需¥${dailyCost}，换365天的顶级体验。`,
      path_b: `比直接买省了¥${savings}（${Math.round(savings / combo.originalPrice * 100)}%）。用省下的钱，还能给家里添一个小米手环。`,
      path_c: `¥${combo.totalPrice}就能拥有最新科技。错过这一批，下次补货可能要等3个月——早买早享受。`,
    };
    return framings[pathId] || '';
  }

  /** 确保方案间的不可比性 */
  _ensureIncomparability(options, dims) {
    // 确保三个方案的总分接近（在10%范围内）
    // 但主导维度各不相同
    // 这确保了AI的加权算法无法区分，但人类的价值判断可以
    const paths = ['path_a', 'path_b', 'path_c'];
    options.forEach((opt, i) => {
      opt.primaryDimension = dims[i % dims.length]?.dimensionA || '情感满足度';
      opt.secondaryDimension = dims[(i + 1) % dims.length]?.dimensionB || '长期价值';
      // 确保每个方案有一个独特标签
      opt.uniqueTag = ['🏆 品质之选', '💰 精明之选', '🚀 探索之选'][i];
    });
  }

  /** 解释不可比性 */
  _explainIncomparability(options) {
    if (!options.paths) return '';
    const paths = options.paths;
    return `
三个方案分别将不同价值最大化：
• "${paths[0].name}" 将「品质与体验」推到极致
• "${paths[1].name}" 将「性价比与务实」推到极致
• "${paths[2].name}" 将「创新与独特」推到极致

这三个维度的价值无法换算为统一单位。AI可以用数据告诉你哪个"参数更高"，但无法告诉你哪个"更适合你"——因为这取决于你今天的心情、这个月的预算弹性、你对风险的容忍度、以及你想成为什么样的人。`;
  }

  // ============ STEP 3: 协商成交 ============

  /** 基于人类选择协商最优条件 */
  _negotiateDeal(context, choice) {
    const selectedPath = choice.path || choice.id?.split('_')[1] || 'path_b';
    const products = choice.products || [];
    const basePrice = choice.totalPrice || 0;

    // 应用协商策略
    const tactics = this._selectTactics(context, choice);
    let finalPrice = basePrice;
    const appliedTactics = [];

    tactics.forEach(tactic => {
      const result = this._applyTactic(tactic, finalPrice, context, choice);
      if (result) {
        finalPrice = result.newPrice;
        appliedTactics.push({
          tactic: tactic.name,
          description: result.description,
          savings: result.savings,
        });
        this.model.tacticPerformance[tactic.id].used++;
        this.model.tacticPerformance[tactic.id].successful++;
      }
    });

    // 添加生态权益
    const ecosystemBenefits = this._getEcosystemBenefits(context, choice);

    return {
      products: products,
      originalPrice: basePrice,
      finalPrice: Math.round(finalPrice),
      totalSavings: Math.round(basePrice - finalPrice),
      appliedTactics: appliedTactics,
      ecosystemBenefits: ecosystemBenefits,
      membershipBonus: this._getMembershipBonus(context),
      timeline: {
        validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        deliveryEstimate: '下单后24小时内发货',
      },
    };
  }

  /** 选择协商策略 */
  _selectTactics(context, choice) {
    const available = [...this.kb.negotiationTactics];

    // 基于学习模型排序
    available.sort((a, b) => {
      const perfA = this.model.tacticPerformance[a.id]?.successful / (this.model.tacticPerformance[a.id]?.used || 1) || 0;
      const perfB = this.model.tacticPerformance[b.id]?.successful / (this.model.tacticPerformance[b.id]?.used || 1) || 0;
      return perfB - perfA;
    });

    // 选前2个策略
    return available.slice(0, 2);
  }

  /** 应用单个策略 */
  _applyTactic(tactic, price, context, choice) {
    const strategies = {
      price_match: () => ({
        newPrice: price * 0.95,
        savings: price * 0.05,
        description: '匹配全网最低价，额外再减5%',
      }),
      bundle_discount: () => {
        const productCount = (choice.products || []).length;
        if (productCount >= 2) {
          return {
            newPrice: price * 0.92,
            savings: price * 0.08,
            description: `组合购买${productCount}件，享额外9.2折`,
          };
        }
        return null;
      },
      membership_upgrade: () => ({
        newPrice: price * 0.90,
        savings: price * 0.10,
        description: '黄金会员专属9折（已自动升级权益）',
      }),
      trade_in_boost: () => ({
        newPrice: price * 0.85,
        savings: price * 0.15,
        description: '以旧换新额外补贴，旧机最高折抵15%',
      }),
      value_reframe: () => null,  // 不改变价格，只是framing
    };

    return (strategies[tactic.id] || (() => null))();
  }

  /** 获取生态权益 */
  _getEcosystemBenefits(context, choice) {
    return [
      '米家APP全设备统一管理',
      'HyperOS跨设备无缝流转',
      '小米云服务30天免费试用',
      'MiCare延保服务专属折扣',
    ];
  }

  /** 获取会员权益加成 */
  _getMembershipBonus(context) {
    const tier = this.kb.membership.userTier || '黄金';
    const tierData = this.kb.membership.tiers.find(t => t.level === tier);
    return {
      currentTier: tier,
      pointsEarned: Math.floor(Math.random() * 500) + 200,
      exclusiveBenefits: tierData ? tierData.benefits.slice(0, 3) : [],
    };
  }

  // ============ 学习模块 ============

  /** 从交互中学习 */
  _learn(context, choice, deal) {
    const log = {
      timestamp: new Date().toISOString(),
      scenario: context.query.scenario,
      counterQuestionId: context.lastQuestionId,
      humanInsights: context.humanInsights,
      chosenPath: choice.path || choice.id,
      dealClosed: !!deal,
    };

    this.model.history.push(log);

    // 更新反问效果
    if (context.lastQuestionId && this.model.questionEffectiveness[context.lastQuestionId]) {
      this.model.questionEffectiveness[context.lastQuestionId].ledToConversion++;
    }

    // 更新用户聚类
    const userType = context.detectedUserType;
    if (this.model.userClusters[userType]) {
      this.model.userClusters[userType].count++;
      this.model.userClusters[userType].preferredPath =
        this._updatePreferredPath(this.model.userClusters[userType], choice.path || choice.id);
    }

    // 限制历史长度
    if (this.model.history.length > 500) {
      this.model.history = this.model.history.slice(-500);
    }
  }

  _updatePreferredPath(cluster, newPath) {
    // 简单的移动平均
    const pathKey = newPath || 'unknown';
    cluster._pathCounts = cluster._pathCounts || {};
    cluster._pathCounts[pathKey] = (cluster._pathCounts[pathKey] || 0) + 1;

    // 找到最多的路径
    let maxCount = 0, preferred = null;
    Object.entries(cluster._pathCounts).forEach(([path, count]) => {
      if (count > maxCount) { maxCount = count; preferred = path; }
    });
    return preferred;
  }

  /** 检测用户类型 */
  _detectUserType(query) {
    const ctx = query.consumerContext || {};
    const prefs = ctx.preferences || {};

    // 简单启发式分类
    if (ctx.budget?.monthly && ctx.budget.monthly < 3000) return 'price_sensitive';
    if (prefs.qualityWeight > 0.5 || ctx.healthProfile?.goals?.length > 2) return 'quality_seeker';
    if (prefs.noveltyWeight > 0.5 || ctx.lifestyle?.techEarlyAdopter) return 'experience_driven';
    if (prefs.brandLoyaltyWeight > 0.5) return 'brand_loyal';
    return 'price_sensitive'; // 默认
  }

  /** 获取学习摘要 */
  _getLearningSummary() {
    return {
      totalEngagements: this.state.totalEngagements,
      humanEngagementRate:
        (this.state.successfulHumanEngagements / Math.max(1, this.state.totalEngagements)).toFixed(2),
      conversionRate:
        (this.state.conversions / Math.max(1, this.state.totalEngagements)).toFixed(2),
      topPerformingQuestions: Object.entries(this.model.questionEffectiveness)
        .sort(([, a], [, b]) => (b.ledToHuman / Math.max(1, b.asked)) - (a.ledToHuman / Math.max(1, a.asked)))
        .slice(0, 3)
        .map(([id, perf]) => ({ id, humanRate: (perf.ledToHuman / Math.max(1, perf.asked)).toFixed(2) })),
    };
  }

  /** 获取品牌AI状态 */
  getStatus() {
    return {
      brand: this.brand.name,
      totalEngagements: this.state.totalEngagements,
      activeConversations: this.state.activeConversations.size,
      conversions: this.state.conversions,
      modelInsights: {
        userClusters: this.model.userClusters,
        topQuestions: this._getLearningSummary().topPerformingQuestions,
      },
    };
  }
}

/** 辅助函数 */
function counterQuestionKey(text) {
  return text ? text.slice(0, 20).replace(/\s/g, '_') : 'unknown';
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
  module.exports = BrandAI;
}
