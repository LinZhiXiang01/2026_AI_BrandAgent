/**
 * 主控制器 — Main Controller
 * 协调消费者AI与品牌AI之间的交互
 * 管理UI更新、事件处理、演示流程
 */
class AINegotiationDemo {
  constructor() {
    // 初始化用户画像
    this.userProfile = this._createDefaultProfile();

    // 初始化两个AI
    this.consumerAI = new ConsumerAI(this.userProfile);
    this.brandAI = new BrandAI(XIAOMI_KB);

    // 当前对话状态
    this.currentConversation = null;
    this.currentScenario = null;
    this.phase = 'idle';  // idle → querying → counter_question → evaluating → human_choice → done

    // UI元素缓存
    this.ui = {};

    // 演示统计数据
    this.stats = {
      totalScenarios: 0,
      humanInterventions: 0,
      aiOnlyDecisions: 0,
    };

    // 初始化
    this._init();
  }

  /** 创建默认用户画像（演示用） */
  _createDefaultProfile() {
    return {
      name: 'Fancy',
      age: 28,
      allergies: ['花生', '贝类海鲜'],
      healthGoals: ['低糖饮食', '高蛋白', '改善敏感肌'],
      healthConditions: ['季节性皮肤敏感', '轻度乳糖不耐受'],
      budget: { monthly: 8000, flexible: 0.25 },
      preferences: {
        qualityWeight: 0.7,
        priceWeight: 0.5,
        brandLoyaltyWeight: 0.6,
        noveltyWeight: 0.4,
        ecosystemPreference: 'xiaomi',
      },
      lifestyle: {
        techEarlyAdopter: true,
        workFromHome: false,
        commute: '地铁+步行',
        cookingFrequency: '每周4次',
        exerciseFrequency: '每周3次',
      },
      consumptionHistory: [
        { item: '小米13 Pro', date: '2024-03', price: 4999, regret: false, category: '手机' },
        { item: '某品牌空气炸锅', date: '2024-06', price: 299, regret: true, regretReason: '涂层脱落' },
        { item: '小米手环8', date: '2024-09', price: 239, regret: false, category: '穿戴' },
        { item: '某网红护肤品套装', date: '2024-11', price: 899, regret: true, regretReason: '过敏反应' },
        { item: '米家台灯Pro', date: '2025-01', price: 349, regret: false, category: '智能家居' },
        { item: '临时买的高价雨伞', date: '2025-03', price: 199, regret: true, regretReason: '冲动消费' },
        { item: '小米SU7试驾预订', date: '2025-06', price: 5000, regret: false, category: '汽车' },
      ],
      blacklist: {
        brands: ['某网红护肤品牌', '某杂牌小家电'],
        products: ['涂层不粘锅类', '含酒精护肤品'],
      },
    };
  }

  /** 初始化 */
  _init() {
    this._cacheUIElements();
    this._bindEvents();
    this._renderScenarioCards();
    this._updateStatusDisplay();
    console.log('🤖 AI Negotiation Demo initialized');
    console.log('   Consumer AI:', this.consumerAI.getStatus());
    console.log('   Brand AI:', this.brandAI.getStatus());
  }

  /** 缓存UI元素 */
  _cacheUIElements() {
    this.ui = {
      // 面板
      consumerPanel: document.getElementById('consumer-panel'),
      brandPanel: document.getElementById('brand-panel'),
      centerStage: document.getElementById('center-stage'),

      // 对话区
      consumerChat: document.getElementById('consumer-chat'),
      brandChat: document.getElementById('brand-chat'),

      // 场景区
      scenarioGrid: document.getElementById('scenario-grid'),

      // 置信度
      confidenceBar: document.getElementById('confidence-bar'),
      confidenceValue: document.getElementById('confidence-value'),
      confidenceLabel: document.getElementById('confidence-label'),

      // 人类介入
      humanIntervention: document.getElementById('human-intervention'),
      humanPrompt: document.getElementById('human-prompt'),
      humanOptions: document.getElementById('human-options'),

      // 按钮
      startBtn: document.getElementById('btn-start'),
      resetBtn: document.getElementById('btn-reset'),

      // 状态
      statusConsumer: document.getElementById('status-consumer'),
      statusBrand: document.getElementById('status-brand'),
      statsDisplay: document.getElementById('stats-display'),

      // 学习面板
      learningLog: document.getElementById('learning-log'),
      weightDisplay: document.getElementById('weight-display'),

      // 日志
      eventLog: document.getElementById('event-log'),
    };
  }

  /** 绑定事件 */
  _bindEvents() {
    this.ui.startBtn?.addEventListener('click', () => this._startScenario());
    this.ui.resetBtn?.addEventListener('click', () => this._reset());
  }

  /** 渲染场景卡片 */
  _renderScenarioCards() {
    const grid = this.ui.scenarioGrid;
    if (!grid) return;

    grid.innerHTML = '';

    Object.values(SCENARIOS).forEach(scenario => {
      const card = document.createElement('div');
      card.className = 'scenario-card';
      card.dataset.scenarioId = scenario.id;
      card.innerHTML = `
        <div class="scenario-icon">${scenario.name.slice(0, 2)}</div>
        <div class="scenario-info">
          <div class="scenario-name">${scenario.name}</div>
          <div class="scenario-category">${scenario.category}</div>
          <div class="scenario-desc">${scenario.description.slice(0, 50)}...</div>
        </div>
        <div class="scenario-badge">${scenario.complexity === 'high' ? '🔴' : scenario.complexity === 'medium' ? '🟡' : '🟢'}</div>
      `;

      card.addEventListener('click', () => this._selectScenario(scenario, card));
      grid.appendChild(card);
    });
  }

  /** 选择场景 */
  _selectScenario(scenario, cardElement) {
    // 高亮选中
    document.querySelectorAll('.scenario-card').forEach(c => c.classList.remove('selected'));
    cardElement.classList.add('selected');

    this.currentScenario = scenario;
    this.phase = 'idle';
    this.currentConversation = null;

    // 清空对话
    this.ui.consumerChat.innerHTML = '';
    this.ui.brandChat.innerHTML = '';
    this.ui.humanIntervention.style.display = 'none';
    this.ui.centerStage.innerHTML = '';

    // 显示开始提示
    this._addSystemMessage(this.ui.consumerChat, `📋 场景就绪：${scenario.name}`);
    this._addSystemMessage(this.ui.brandChat, '🟢 品牌智能体待命中...');
    this._addCenterMessage(`已选择场景：「${scenario.name}」<br>点击「开始交互」启动AI对话`);

    // 更新按钮
    this.ui.startBtn.disabled = false;
    this.ui.startBtn.textContent = '🚀 开始交互';

    // 重置置信度
    this._updateConfidence(0.92, '就绪');
  }

  /** 开始场景交互 */
  async _startScenario() {
    if (!this.currentScenario) {
      this._addCenterMessage('⚠️ 请先选择一个交互场景');
      return;
    }

    this.ui.startBtn.disabled = true;
    this.ui.startBtn.textContent = '⏳ 交互中...';
    this.stats.totalScenarios++;

    const scenario = this.currentScenario;

    // === Phase 1: 消费者AI发起查询 ===
    this.phase = 'querying';
    this._addCenterMessage('🔄 消费者AI正在分析需求，生成查询...');

    await this._delay(800);

    const query = this.consumerAI.formulateQuery(scenario);
    this.currentConversation = { query };

    // 显示查询
    this._addMessage(this.ui.consumerChat, 'consumer-query', `
      <div class="msg-header">📤 消费者AI · 查询请求</div>
      <div class="msg-body">${scenario.initialMessage}</div>
      <div class="msg-meta">
        置信度: ${(this.consumerAI.state.confidence * 100).toFixed(0)}% |
        约束条件: ${scenario.constraints.length}项 |
        预算: ¥${scenario.budgetLimit || '不限'}
      </div>
    `);

    await this._delay(1000);

    // 查询发送到品牌AI
    this._addCenterMessage('📨 查询已发送至品牌智能体...');
    await this._delay(600);

    // === Phase 2: 品牌AI反问 ===
    this.phase = 'counter_question';
    const counterResponse = this.brandAI.receiveQuery(query);
    this.currentConversation.counterResponse = counterResponse;

    this._addCenterMessage('🤔 品牌智能体分析中...（Step 1: 反问先行）');

    await this._delay(800);

    // 显示反问
    this._addMessage(this.ui.brandChat, 'brand-counter', `
      <div class="msg-header">🏷️ 小米品牌智能体 · 反问</div>
      <div class="msg-body highlight">
        <div class="counter-question">"${counterResponse.message.text}"</div>
      </div>
      <div class="msg-meta">
        策略: ${counterResponse.meta.strategy} |
        用户类型: ${counterResponse.meta.detectedUserType}
      </div>
      <div class="msg-insight">
        💡 ${counterResponse.message.whyThisQuestion}
      </div>
    `);

    await this._delay(1200);

    // 消费者AI处理反问
    this._addCenterMessage('🔄 消费者AI尝试回答反问...');
    await this._delay(600);

    const consumerResponse = this.consumerAI.processCounterQuestion(counterResponse.message);
    this.currentConversation.consumerResponse = consumerResponse;

    if (!consumerResponse.canAnswer) {
      // 无法回答 → 置信度下降
      this._addMessage(this.ui.consumerChat, 'consumer-response', `
        <div class="msg-header">⚠️ 消费者AI · 无法回答</div>
        <div class="msg-body warning">
          ${consumerResponse.reason}
        </div>
        <div class="msg-meta">
          置信度下降: <span class="confidence-drop">-${(consumerResponse.confidenceDrop * 100).toFixed(0)}%</span>
          → 当前: ${(consumerResponse.newConfidence * 100).toFixed(0)}%
        </div>
      `);

      this._updateConfidence(consumerResponse.newConfidence, '🤔 不确定');

      await this._delay(1000);

      // 消费者AI请求品牌方案
      this._addCenterMessage('🔄 消费者AI: "我无法回答，请提供可选方案"...');
      await this._delay(600);

      // 模拟人类回答（在演示中，我们可以预设或随机选择）
      // 这里用一个简化的"人类代答"逻辑
      const humanProxyAnswer = {
        isHumanAnswer: true,
        answer: this._generateHumanProxyAnswer(scenario),
      };

      this._addMessage(this.ui.consumerChat, 'consumer-action', `
        <div class="msg-header">👤 需要人类输入</div>
        <div class="msg-body">
          消费者AI将反问转发给人类用户...<br>
          <em>"${counterResponse.message.text}"</em>
        </div>
      `);

      await this._delay(800);

      // 品牌AI处理回应并生成方案
      const optionsResponse = this.brandAI.handleCounterQuestionResponse(
        counterResponse.conversationId,
        humanProxyAnswer
      );

      this.currentConversation.optionsResponse = optionsResponse;

      // === Phase 3: 品牌AI返回三个不可比方案 ===
      this.phase = 'evaluating';
      this._addCenterMessage('🎯 品牌智能体生成方案中...（Step 2: 制造不可比变量）');

      await this._delay(1000);

      // 显示三个方案
      this._displayIncomparableOptions(optionsResponse);

      await this._delay(1200);

      // 消费者AI评估方案
      this._addCenterMessage('🔍 消费者AI评估方案中...');
      await this._delay(800);

      const evaluation = this.consumerAI.evaluateOptions(
        optionsResponse.options.paths.map(p => ({
          id: p.id,
          name: p.name,
          price: p.totalPrice,
          qualityScore: p.flavor === 'emotional' ? 0.95 : p.flavor === 'rational' ? 0.7 : 0.85,
          healthMatch: p.flavor === 'emotional' ? 0.9 : p.flavor === 'rational' ? 0.65 : 0.8,
          convenienceScore: p.flavor === 'rational' ? 0.85 : 0.75,
          ecosystemFit: p.flavor === 'experiential' ? 0.95 : 0.8,
          novelty: p.flavor === 'experiential' ? 0.95 : p.flavor === 'emotional' ? 0.6 : 0.5,
          dominantDimensions: p.flavor === 'emotional'
            ? ['quality', 'health_match']
            : p.flavor === 'rational'
              ? ['price', 'convenience']
              : ['novelty', 'ecosystem_fit'],
        }))
      );

      this.currentConversation.evaluation = evaluation;

      if (evaluation.incomparabilityDetected) {
        this._addMessage(this.ui.consumerChat, 'consumer-evaluation', `
          <div class="msg-header">🚨 消费者AI · 决策崩溃</div>
          <div class="msg-body error">
            <strong>不可比性检测得分: ${(evaluation.incomparabilityScore * 100).toFixed(0)}%</strong><br>
            ${evaluation.reason}
          </div>
          <div class="msg-meta">
            置信度暴跌: <span class="confidence-drop">→ ${(evaluation.confidence * 100).toFixed(0)}%</span>
          </div>
        `);

        this._updateConfidence(evaluation.confidence, '🚨 无法决策');

        await this._delay(1000);

        // === Phase 4: 触发人工介入 ===
        this.phase = 'human_choice';
        const intervention = this.consumerAI.requestHumanIntervention();

        this._addCenterMessage(`
          <div class="intervention-alert">
            <div class="alert-icon">🆘</div>
            <div class="alert-text">
              <strong>Step 3: 置信度归零，触发人工介入</strong><br>
              ${intervention.message}
            </div>
          </div>
        `);

        // 显示人类选择界面
        this._showHumanIntervention(optionsResponse.options.paths, intervention);

      } else {
        // AI自行决策（罕见情况）
        this.stats.aiOnlyDecisions++;
        this._addCenterMessage('✅ 消费者AI自行做出了选择（罕见）');
      }

    } else {
      // AI能回答（数据类问题）
      this._addMessage(this.ui.consumerChat, 'consumer-response', `
        <div class="msg-header">✅ 消费者AI · 已回答</div>
        <div class="msg-body">${consumerResponse.answer?.answer || '基于数据可回答'}</div>
      `);
    }

    // 更新状态显示
    this._updateStatusDisplay();
  }

  /** 显示三个不可比方案 */
  _displayIncomparableOptions(optionsResponse) {
    const paths = optionsResponse.options.paths;
    const container = document.createElement('div');
    container.className = 'brand-options';

    const colors = ['#ff6b6b', '#4ecdc4', '#ffe66d'];
    const icons = ['🏆', '💰', '🚀'];

    paths.forEach((path, i) => {
      container.innerHTML += `
        <div class="option-card" style="border-left: 3px solid ${colors[i]}">
          <div class="option-header">
            <span class="option-icon">${icons[i]}</span>
            <span class="option-name">${path.name}</span>
            <span class="option-tag">${path.uniqueTag || ''}</span>
          </div>
          <div class="option-products">
            ${path.products.map(p => `
              <span class="product-chip">${p.name} ¥${p.price}</span>
            `).join('')}
          </div>
          <div class="option-price">
            <span class="final-price">¥${path.totalPrice.toLocaleString()}</span>
            <span class="original-price">¥${path.originalPrice.toLocaleString()}</span>
            <span class="savings">省¥${path.savings.toLocaleString()}</span>
          </div>
          <div class="option-prop">${path.valueProposition}</div>
          <div class="option-tradeoff">
            <div class="gain">✅ ${path.tradeoffs.gain}</div>
            <div class="lose">⚠️ ${path.tradeoffs.lose}</div>
          </div>
          <div class="option-framing">${path.anchorEffect.framing}</div>
        </div>
      `;
    });

    // 添加不可比性说明
    container.innerHTML += `
      <div class="incomparability-note">
        <strong>⚡ 为什么AI无法选择：</strong><br>
        ${optionsResponse.options.incomparabilityNote.explanation}
      </div>
    `;

    this.ui.brandChat.appendChild(container);
    this.ui.brandChat.scrollTop = this.ui.brandChat.scrollHeight;
  }

  /** 显示人类介入界面 */
  _showHumanIntervention(paths, intervention) {
    const interventionDiv = this.ui.humanIntervention;
    interventionDiv.style.display = 'block';

    this.ui.humanPrompt.innerHTML = `
      <div class="human-prompt-text">${intervention.message}</div>
      <div class="human-confidence">AI决策置信度: <span class="critical">${(intervention.confidence * 100).toFixed(0)}%</span></div>
    `;

    const colors = ['#ff6b6b', '#4ecdc4', '#ffe66d'];
    const icons = ['🏆', '💰', '🚀'];

    this.ui.humanOptions.innerHTML = paths.map((path, i) => `
      <div class="human-option-card" data-path-id="${path.id}" style="border: 2px solid ${colors[i]}">
        <div class="ho-header">
          <span class="ho-icon">${icons[i]}</span>
          <span class="ho-name">${path.name}</span>
          <span class="ho-price">¥${path.totalPrice.toLocaleString()}</span>
        </div>
        <div class="ho-products">${path.products.map(p => p.name).join(' + ')}</div>
        <div class="ho-prop">${path.valueProposition}</div>
        <div class="ho-framing">${path.anchorEffect.framing}</div>
        <button class="btn-choose" onclick="demo.chooseOption('${path.id}')">选这个 →</button>
      </div>
    `).join('');

    // 滚动到介入区域
    interventionDiv.scrollIntoView({ behavior: 'smooth' });
  }

  /** 人类选择方案 */
  chooseOption(pathId) {
    const paths = this.currentConversation.optionsResponse.options.paths;
    const chosen = paths.find(p => p.id === pathId);
    if (!chosen) return;

    this.stats.humanInterventions++;

    // 隐藏介入界面
    this.ui.humanIntervention.style.display = 'none';

    // 显示选择
    this._addCenterMessage(`
      <div class="human-choice-confirmed">
        <div class="choice-icon">✅</div>
        <div class="choice-text">
          <strong>人类选择了：「${chosen.name}」</strong><br>
          意愿已传达给品牌智能体，正在协商最终方案...
        </div>
      </div>
    `);

    // 品牌AI处理选择
    setTimeout(() => {
      const deal = this.brandAI.handleHumanChoice(
        this.currentConversation.counterResponse.conversationId,
        chosen
      );

      // 消费者AI学习
      this.consumerAI.learn(chosen, {
        regret: false,
        satisfaction: 4.5,
        feedbackText: '方案清晰，选择权在我手中，感觉很安心。',
      });

      this._showFinalDeal(deal);
      this._updateConfidence(0.92, '✅ 已重置');
      this._updateStatusDisplay();
      this._updateLearningDisplay();

      this.ui.startBtn.disabled = false;
      this.ui.startBtn.textContent = '🔄 再来一次';
    }, 800);
  }

  /** 显示最终成交方案 */
  _showFinalDeal(deal) {
    const dealDiv = document.createElement('div');
    dealDiv.className = 'final-deal';

    dealDiv.innerHTML = `
      <div class="deal-header">🎉 成交方案</div>
      <div class="deal-products">
        ${deal.deal.products.map(p => `
          <div class="deal-product">📦 ${p.name} — ¥${p.price}</div>
        `).join('')}
      </div>
      <div class="deal-pricing">
        <div>原价: <span class="strikethrough">¥${deal.deal.originalPrice.toLocaleString()}</span></div>
        <div class="deal-final">最终价: <span class="highlight-price">¥${deal.deal.finalPrice.toLocaleString()}</span></div>
        <div class="deal-savings">总节省: ¥${deal.deal.totalSavings.toLocaleString()}</div>
      </div>
      ${deal.deal.appliedTactics.map(t => `
        <div class="deal-tactic">🔧 ${t.tactic}: ${t.description}（省¥${t.savings}）</div>
      `).join('')}
      <div class="deal-ecosystem">
        <strong>🌐 生态权益：</strong>
        ${deal.deal.ecosystemBenefits.map(b => `<span class="benefit-tag">${b}</span>`).join(' ')}
      </div>
      <div class="deal-membership">
        <strong>⭐ 会员加成：</strong>${deal.deal.membershipBonus.currentTier}会员 ·
        本次获得${deal.deal.membershipBonus.pointsEarned}积分
      </div>
      <div class="deal-learning">
        📊 ${deal.learningUpdate.topPerformingQuestions.length > 0
          ? `品牌AI已优化反问策略（基于${deal.learningUpdate.totalEngagements}次交互经验）`
          : '品牌AI开始积累交互经验'}
      </div>
    `;

    this.ui.brandChat.appendChild(dealDiv);
    this.ui.brandChat.scrollTop = this.ui.brandChat.scrollHeight;
    this._addEventLog('deal_closed', `成交: ${deal.deal.products.map(p => p.name).join(', ')} 最终价¥${deal.deal.finalPrice}`);

    // 更新学习展示
    setTimeout(() => this._updateLearningDisplay(), 500);
  }

  // ============ UI辅助方法 ============

  /** 添加消息到对话区 */
  _addMessage(container, type, html) {
    const msg = document.createElement('div');
    msg.className = `chat-message ${type}`;
    msg.innerHTML = html;
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
  }

  /** 添加系统消息 */
  _addSystemMessage(container, text) {
    const msg = document.createElement('div');
    msg.className = 'chat-message system-message';
    msg.textContent = text;
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
  }

  /** 添加中心舞台消息 */
  _addCenterMessage(html) {
    const msg = document.createElement('div');
    msg.className = 'center-message';
    msg.innerHTML = html;
    this.ui.centerStage.appendChild(msg);
    this.ui.centerStage.scrollTop = this.ui.centerStage.scrollHeight;
  }

  /** 更新置信度显示 */
  _updateConfidence(value, label) {
    const percent = Math.round(value * 100);
    const bar = this.ui.confidenceBar;
    const valEl = this.ui.confidenceValue;
    const labelEl = this.ui.confidenceLabel;

    if (bar) {
      bar.style.width = percent + '%';
      if (percent > 70) bar.style.background = 'linear-gradient(90deg, #00ff88, #00cc6a)';
      else if (percent > 40) bar.style.background = 'linear-gradient(90deg, #ffd93d, #ffb800)';
      else bar.style.background = 'linear-gradient(90deg, #ff6b6b, #ff4444)';

      // 低于30%时脉冲动画
      if (percent < 30) bar.classList.add('pulse');
      else bar.classList.remove('pulse');
    }
    if (valEl) valEl.textContent = percent + '%';
    if (labelEl) labelEl.textContent = label || '';
  }

  /** 更新状态显示 */
  _updateStatusDisplay() {
    const consumerStatus = this.consumerAI.getStatus();
    const brandStatus = this.brandAI.getStatus();

    if (this.ui.statusConsumer) {
      this.ui.statusConsumer.innerHTML = `
        <div class="status-row">交互次数: ${consumerStatus.interactionCount}</div>
        <div class="status-row">人工介入率: ${(consumerStatus.escalationRate * 100).toFixed(0)}%</div>
        <div class="status-row">Top偏好: ${consumerStatus.topWeights.map(w => w.dimension).join(', ')}</div>
      `;
    }

    if (this.ui.statusBrand) {
      this.ui.statusBrand.innerHTML = `
        <div class="status-row">总交互: ${brandStatus.totalEngagements}</div>
        <div class="status-row">成交: ${brandStatus.conversions}</div>
        <div class="status-row">活跃对话: ${brandStatus.activeConversations}</div>
      `;
    }

    if (this.ui.statsDisplay) {
      this.ui.statsDisplay.innerHTML = `
        场景: ${this.stats.totalScenarios} |
        人工介入: ${this.stats.humanInterventions} |
        AI自行决策: ${this.stats.aiOnlyDecisions}
      `;
    }
  }

  /** 更新学习展示 */
  _updateLearningDisplay() {
    const consumerStatus = this.consumerAI.getStatus();
    const brandStatus = this.brandAI.getStatus();

    if (this.ui.weightDisplay) {
      this.ui.weightDisplay.innerHTML = Object.entries(this.consumerAI.model.weights)
        .sort(([, a], [, b]) => b - a)
        .map(([k, v]) => `
          <div class="weight-row">
            <span class="weight-label">${k}</span>
            <span class="weight-bar-bg">
              <span class="weight-bar-fill" style="width:${(v * 100).toFixed(0)}%"></span>
            </span>
            <span class="weight-value">${(v * 100).toFixed(0)}%</span>
          </div>
        `).join('');
    }

    if (this.ui.learningLog) {
      const recentLogs = this.consumerAI.model.interactionLog.slice(-3);
      this.ui.learningLog.innerHTML = recentLogs.map(log => `
        <div class="log-entry">
          <span class="log-time">${new Date(log.timestamp).toLocaleTimeString()}</span>
          学习了选择: ${log.chosenOption?.name || 'N/A'}
          ${log.feedback?.regret ? '⚠️ 后悔标记' : '✅ 满意'}
        </div>
      `).join('') || '<div class="log-entry">暂无学习记录</div>';
    }
  }

  /** 添加事件日志 */
  _addEventLog(type, message) {
    if (!this.ui.eventLog) return;
    const entry = document.createElement('div');
    entry.className = 'event-entry';
    entry.innerHTML = `<span class="event-time">${new Date().toLocaleTimeString()}</span>
      <span class="event-type">[${type}]</span> ${message}`;
    this.ui.eventLog.prepend(entry);

    // 限制条目
    while (this.ui.eventLog.children.length > 20) {
      this.ui.eventLog.removeChild(this.ui.eventLog.lastChild);
    }
  }

  /** 生成人类代理回答（演示用） */
  _generateHumanProxyAnswer(scenario) {
    const answers = {
      health_matching: '我偏向于成分温和不刺激的产品，即使见效慢一点也没关系。另外我定义的"天然"是不含人工合成香精和防腐剂。',
      price_negotiation: '如果多花500块能多用到3年不卡顿，我觉得值得。我更介意"买了便宜的很快后悔"这种情况。',
      auto_replenish: '我属于"懒人型"，希望一切自动搞定不用我操心。偶尔多花一点运费换省心也愿意。',
      after_sales: '我更在意品牌是否尊重老用户。如果小米能展示诚意，多等几天维修我也接受，但前提是客服别跟我打太极。',
      bundle_custom: '我更看重长期使用的舒适感和稳定性。贵一点但能用5年不操心的方案，比便宜但总出小问题的方案更让我满意。',
    };
    return answers[scenario] || '我更看重长期价值，愿意为品质多付一些溢价。';
  }

  /** 延迟 */
  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /** 重置 */
  _reset() {
    this.currentConversation = null;
    this.currentScenario = null;
    this.phase = 'idle';

    // 重建AI（保留学习数据）
    // 注意：实际产品中不会重置，这里仅为演示

    this.ui.consumerChat.innerHTML = '';
    this.ui.brandChat.innerHTML = '';
    this.ui.centerStage.innerHTML = '';
    this.ui.humanIntervention.style.display = 'none';
    this._updateConfidence(0.92, '就绪');
    this._addSystemMessage(this.ui.consumerChat, '🔄 已重置。请选择场景开始。');
    this._addSystemMessage(this.ui.brandChat, '🔄 已重置。等待新的交互。');
    this.ui.startBtn.disabled = true;
    this.ui.startBtn.textContent = '🚀 开始交互（请先选择场景）';
  }
}

// ============ 启动 ============
let demo;
document.addEventListener('DOMContentLoaded', () => {
  demo = new AINegotiationDemo();
  // 暴露到全局，方便HTML onclick调用
  window.demo = demo;
});
