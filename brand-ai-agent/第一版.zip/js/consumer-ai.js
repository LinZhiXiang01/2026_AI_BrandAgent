/**
 * 消费者AI引擎 — Consumer AI Agent
 *
 * 核心设计原则：
 * 1. 非预设脚本 — 每次交互基于当前状态动态生成
 * 2. 持续学习 — 从交互结果中更新偏好权重和决策模型
 * 3. 置信度驱动 — 量化决策不确定性，低于阈值触发人工介入
 * 4. 多维度评分 — 模拟真实消费者的复杂权衡过程
 */
class ConsumerAI {
  constructor(userProfile) {
    this.profile = userProfile;
    this.state = {
      confidence: 0.92,             // 当前决策置信度 [0, 1]
      confidenceHistory: [],         // 置信度变化轨迹
      pendingDecision: null,        // 待决策事项
      evaluatedOptions: [],         // 已评估选项
      interactionCount: 0,          // 总交互次数
      humanEscalations: 0,          // 人工介入次数
      lastInteraction: null,
    };

    // 学习模型
    this.model = {
      // 偏好权重 — 动态调整
      weights: {
        price: 0.25,
        quality: 0.20,
        health_match: 0.15,
        convenience: 0.10,
        brand_loyalty: 0.10,
        sustainability: 0.05,
        social_value: 0.05,
        novelty: 0.05,
        ecosystem_fit: 0.05,
      },

      // 后悔记忆 — 记录过去的后悔决策模式
      regretPatterns: [],

      // 品牌黑名单 — 踩过坑的品牌
      brandBlacklist: new Set(),

      // 消费历史摘要
      consumptionSummary: {},

      // 交互学习记录
      interactionLog: [],

      // 学习率
      learningRate: 0.05,

      // 风险偏好 [0保守, 1激进]
      riskTolerance: 0.4,
    };

    // 初始化学习状态
    this._initializeFromProfile();
  }

  /** 从用户画像初始化学习参数 */
  _initializeFromProfile() {
    const p = this.profile;

    // 根据消费历史调整权重
    if (p.consumptionHistory) {
      const regretCount = p.consumptionHistory.filter(h => h.regret).length;
      this.model.riskTolerance = Math.max(0.1, 0.5 - regretCount * 0.05);
      this.model.regretPatterns = p.consumptionHistory.filter(h => h.regret);
    }

    // 根据健康目标调整权重
    if (p.healthGoals && p.healthGoals.length > 0) {
      this.model.weights.health_match = 0.20;
      this.model.weights.price = 0.20;
    }

    // 根据黑名单调整
    if (p.blacklist) {
      (p.blacklist.brands || []).forEach(b => this.model.brandBlacklist.add(b));
    }
  }

  /**
   * 生成查询 — 根据场景和用户画像，动态构造发给品牌AI的查询
   * @param {Object} scenario - 场景定义
   * @returns {Object} 查询对象
   */
  formulateQuery(scenario) {
    this.state.interactionCount++;
    const p = this.profile;

    // 动态查询模板
    const query = {
      id: `q_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      scenario: scenario.id,
      timestamp: new Date().toISOString(),
      consumerContext: {
        // 用户画像摘要（脱敏）
        ageGroup: p.age ? `${Math.floor(p.age / 10) * 10}s` : 'unknown',
        healthProfile: {
          allergies: p.allergies || [],
          goals: p.healthGoals || [],
          conditions: p.healthConditions || [],
        },
        budget: {
          monthly: p.budget?.monthly || 5000,
          flexibility: p.budget?.flexible || 0.2,
          currentLimit: scenario.budgetLimit || p.budget?.monthly || 5000,
        },
        preferences: p.preferences || {},
        lifestyle: p.lifestyle || {},
        // 关键：不发送完整的个人数据，只发送查询相关的上下文
      },
      requirements: scenario.requirements || [],
      constraints: scenario.constraints || [],
      // 预留"AI无法回答"的字段
      unresolvedHumanQuestions: [],
    };

    this.state.pendingDecision = query;
    this.state.evaluatedOptions = [];
    this.state.confidence = this._calculateInitialConfidence(scenario);

    return query;
  }

  /** 计算初始决策置信度 */
  _calculateInitialConfidence(scenario) {
    let confidence = 0.90;

    // 场景复杂度降低置信度
    if (scenario.complexity === 'high') confidence -= 0.10;
    if (scenario.constraints && scenario.constraints.length > 3) confidence -= 0.05;
    if (scenario.requirements && scenario.requirements.length > 5) confidence -= 0.05;

    // 用户画像完整性提高置信度
    if (this.profile.consumptionHistory && this.profile.consumptionHistory.length > 10) confidence += 0.05;
    if (this.profile.preferences && Object.keys(this.profile.preferences).length > 5) confidence += 0.03;

    return Math.min(0.95, Math.max(0.50, confidence));
  }

  /**
   * 处理品牌AI的反问
   * 这是核心逻辑：识别哪些问题是"AI无法独立回答的"
   * @param {Object} counterQuestion - 品牌AI的反问
   * @returns {Object} 处理结果
   */
  processCounterQuestion(counterQuestion) {
    // 分析问题类型
    const analysis = this._analyzeQuestionType(counterQuestion);

    // 如果属于"人类判断"领域 → 置信度下降
    if (analysis.requiresHumanJudgment) {
      const drop = 0.15 + Math.random() * 0.10; // 下降15-25%
      this.state.confidence = Math.max(0.10, this.state.confidence - drop);

      this.state.confidenceHistory.push({
        event: 'counter_question_unanswerable',
        question: counterQuestion.text,
        reason: analysis.reason,
        confidenceBefore: this.state.confidence + drop,
        confidenceAfter: this.state.confidence,
        drop: drop,
        timestamp: new Date().toISOString(),
      });

      return {
        canAnswer: false,
        reason: analysis.reason,
        confidenceDrop: drop,
        newConfidence: this.state.confidence,
        requiresHumanInput: true,
        suggestedHumanPrompt: counterQuestion.text,
      };
    }

    // 如果AI能回答（纯数据类问题）→ 直接回答
    return {
      canAnswer: true,
      answer: this._generateAnswer(counterQuestion),
      confidenceChange: 0,
      newConfidence: this.state.confidence,
    };
  }

  /** 分析问题是否需要人类判断 */
  _analyzeQuestionType(question) {
    const text = question.text || question;

    // 需要人类判断的关键词模式
    const humanJudgmentPatterns = [
      /更介意|更在意|更看重|更喜欢|更倾向/,
      /你觉得|你认为|您觉得|您认为/,
      /哪种.*感受|哪种.*体验|哪种.*适合/,
      /后悔.*多|后悔.*少/,
      /为自己.*还是.*为别人/,
      /取悦自己|被他人认可/,
      /够用就好|一步到位/,
      /牺牲.*还是.*牺牲/,
      /你的消费观|您的消费观/,
      /值得吗|值不值/,
      /愿意.*牺牲|愿意.*放弃/,
      /偏向|偏好|取向/,
      /心情|感受|体验感/,
      /社交|面子|认同/,
      /个性|风格|品味/,
    ];

    const dataAnswerablePatterns = [
      /价格|多少钱|降价|涨价/,
      /规格|参数|配置/,
      /库存|有货|缺货/,
      /是否含有|成分|配料/,
      /产地|批次|日期/,
      /会员等级|积分|优惠券/,
      /配送|物流|门店/,
      /售后|保修|退换/,
    ];

    const humanMatches = humanJudgmentPatterns.filter(p => p.test(text));
    const dataMatches = dataAnswerablePatterns.filter(p => p.test(text));

    // 如果人类判断指标多于数据指标 → 需要人类介入
    if (humanMatches.length > dataMatches.length) {
      return {
        requiresHumanJudgment: true,
        reason: `该问题涉及主观偏好和情境依赖的价值判断，AI无法代理决策。匹配到${humanMatches.length}个主观判断维度。`,
      };
    }

    return {
      requiresHumanJudgment: humanMatches.length > 0,
      reason: humanMatches.length > 0
        ? '问题包含主观判断成分，但可能仍有数据支撑空间'
        : '该问题可基于客观数据回答',
    };
  }

  /** 尝试生成答案（针对可回答的问题） */
  _generateAnswer(question) {
    // 基于用户画像和消费历史生成答案
    return {
      based_on: '用户历史偏好数据',
      confidence: 0.75,
      answer: '基于您的历史数据推断...',
    };
  }

  /**
   * 评估品牌AI返回的方案
   * 核心：检测"不可比变量" → 置信度崩溃
   * @param {Array} options - 品牌AI返回的方案数组
   * @returns {Object} 评估结果
   */
  evaluateOptions(options) {
    if (!options || options.length === 0) {
      this.state.confidence = 0;
      return { canDecide: false, reason: '无可评估方案' };
    }

    const scores = options.map(opt => this._scoreOption(opt));

    // 检测不可比性
    const incomparabilityScore = this._detectIncomparability(scores);

    this.state.evaluatedOptions = scores;

    // 如果方案高度不可比 → 置信度大幅下降
    if (incomparabilityScore > 0.6) {
      const drop = 0.25 + incomparabilityScore * 0.25;
      this.state.confidence = Math.max(0.05, this.state.confidence - drop);

      this.state.confidenceHistory.push({
        event: 'incomparability_detected',
        score: incomparabilityScore,
        confidenceBefore: this.state.confidence + drop,
        confidenceAfter: this.state.confidence,
        drop: drop,
        timestamp: new Date().toISOString(),
      });
    }

    // 如果置信度低于阈值 → 触发人工介入
    const needsHuman = this.state.confidence < 0.30;

    return {
      canDecide: !needsHuman,
      scores: scores,
      incomparabilityDetected: incomparabilityScore > 0.6,
      incomparabilityScore: incomparabilityScore,
      confidence: this.state.confidence,
      needsHumanIntervention: needsHuman,
      reason: needsHuman
        ? `决策置信度已降至${(this.state.confidence * 100).toFixed(0)}%，低于30%阈值。方案间存在${(incomparabilityScore * 100).toFixed(0)}%的不可比维度，需要人类做出价值判断。`
        : `AI可在${(this.state.confidence * 100).toFixed(0)}%置信度下做出选择。`,
      topPick: needsHuman ? null : scores[0],
    };
  }

  /** 对单个方案进行多维度评分 */
  _scoreOption(option) {
    const w = this.model.weights;
    let score = 0;
    const dimensionScores = {};

    // 价格维度
    if (option.price) {
      const budget = this.profile.budget?.monthly || 5000;
      const priceRatio = option.price / budget;
      dimensionScores.price = priceRatio < 0.3 ? 0.9 : priceRatio < 0.6 ? 0.6 : priceRatio < 1 ? 0.3 : 0.1;
      score += dimensionScores.price * w.price;
    }

    // 品质维度
    if (option.qualityScore) {
      dimensionScores.quality = option.qualityScore;
      score += dimensionScores.quality * w.quality;
    }

    // 健康匹配
    if (option.healthMatch) {
      dimensionScores.health_match = option.healthMatch;
      score += dimensionScores.health_match * w.health_match;
    }

    // 品牌忠诚
    if (option.brand === 'xiaomi' || option.brand === '小米') {
      dimensionScores.brand_loyalty = 0.9;
      score += dimensionScores.brand_loyalty * w.brand_loyalty;
    }

    // 便利性
    if (option.convenienceScore) {
      dimensionScores.convenience = option.convenienceScore;
      score += dimensionScores.convenience * w.convenience;
    }

    // 生态适配
    if (option.ecosystemFit) {
      dimensionScores.ecosystem_fit = option.ecosystemFit;
      score += dimensionScores.ecosystem_fit * w.ecosystem_fit;
    }

    // 新颖度
    if (option.novelty) {
      dimensionScores.novelty = option.novelty;
      score += dimensionScores.novelty * w.novelty;
    }

    return {
      option: option,
      totalScore: score,
      dimensionScores: dimensionScores,
      // 标记该选项在哪几个维度上突出
      dominantDimensions: Object.entries(dimensionScores)
        .filter(([, v]) => v > 0.7)
        .map(([k]) => k),
    };
  }

  /**
   * 检测方案间的不可比性
   * 不可比 = 各方案在不同维度上各有优势，无法简单加权求和
   */
  _detectIncomparability(scoredOptions) {
    if (scoredOptions.length < 2) return 0;

    const dimensions = Object.keys(this.model.weights);
    let incomparabilityScore = 0;

    // 对每个维度，检查是否存在"轮流第一"现象
    dimensions.forEach(dim => {
      const values = scoredOptions.map(s => s.dimensionScores[dim] || 0);
      const maxVal = Math.max(...values);
      const winners = values.filter(v => v === maxVal);
      // 如果该维度只有一个赢家，且不同维度有不同赢家 → 不可比
      if (winners.length === 1) {
        incomparabilityScore += 1 / dimensions.length;
      }
    });

    // 如果总分非常接近但维度分布完全不同 → 更高不可比性
    const totalScores = scoredOptions.map(s => s.totalScore);
    const maxScore = Math.max(...totalScores);
    const minScore = Math.min(...totalScores);
    if (maxScore - minScore < 0.1) {
      incomparabilityScore += 0.3;
    }

    // 检查主导维度是否互斥
    const dominantSets = scoredOptions.map(s => new Set(s.dominantDimensions));
    const allSame = dominantSets.every(s =>
      s.size === dominantSets[0].size && [...s].every(x => dominantSets[0].has(x))
    );
    if (!allSame) {
      incomparabilityScore += 0.2;
    }

    return Math.min(1, incomparabilityScore);
  }

  /**
   * 触发人工介入
   * @returns {Object} 人类决策请求
   */
  requestHumanIntervention() {
    this.state.humanEscalations++;

    return {
      type: 'HUMAN_INTERVENTION_REQUIRED',
      consumerAI: this.state,
      confidence: this.state.confidence,
      confidenceHistory: this.state.confidenceHistory,
      evaluatedOptions: this.state.evaluatedOptions,
      message: this._generateInterventionMessage(),
      suggestedAction: '请人类用户基于个人价值观和情境做出最终选择。',
    };
  }

  /** 生成人类可读的介入消息 */
  _generateInterventionMessage() {
    const c = this.state.confidence;
    if (c < 0.10) {
      return '🚨 我的决策系统已无法做出判断。以下选项在完全不同的维度上各有优势，这不是一个数学问题——它关乎您的个人价值观、当前心情和人生阶段。请亲自决定。';
    } else if (c < 0.20) {
      return '⚠️ 我的推荐置信度严重不足。这些选项各有利弊，且利弊分布在不可直接比较的维度上。需要您的价值判断来打破僵局。';
    } else {
      return '⚡ 我发现了一个超出我决策能力的情况。几个选项都合理，但它们代表了不同的生活哲学。请您定夺。';
    }
  }

  /**
   * 学习更新 — 从人类选择中学习
   * @param {Object} chosenOption - 人类选择的方案
   * @param {Object} feedback - 显式反馈
   */
  learn(chosenOption, feedback = {}) {
    const log = {
      timestamp: new Date().toISOString(),
      chosenOption: chosenOption,
      rejectedOptions: this.state.evaluatedOptions
        .filter(s => s.option.id !== chosenOption.id)
        .map(s => s.option),
      feedback: feedback,
    };

    this.model.interactionLog.push(log);

    // 更新权重
    this._updateWeights(chosenOption, feedback);

    // 更新后悔模式
    if (feedback.regret) {
      this.model.regretPatterns.push({
        choice: chosenOption.id,
        category: chosenOption.category,
        reason: feedback.regretReason,
      });
    }

    // 更新品牌黑名单
    if (feedback.blacklistBrand) {
      this.model.brandBlacklist.add(feedback.blacklistBrand);
    }

    // 限制记忆长度
    if (this.model.interactionLog.length > 100) {
      this.model.interactionLog = this.model.interactionLog.slice(-100);
    }

    // 重置置信度
    this.state.confidence = 0.92;
    this.state.pendingDecision = null;
    this.state.evaluatedOptions = [];
  }

  /** 根据人类选择调整偏好权重 */
  _updateWeights(chosenOption, feedback) {
    const lr = this.model.learningRate;
    const w = this.model.weights;

    if (chosenOption.dominantDimensions) {
      chosenOption.dominantDimensions.forEach(dim => {
        if (w[dim] !== undefined) {
          w[dim] = Math.min(0.4, w[dim] + lr);
        }
      });
    }

    // 重新归一化
    const total = Object.values(w).reduce((a, b) => a + b, 0);
    Object.keys(w).forEach(k => { w[k] = w[k] / total; });
  }

  /** 获取当前状态摘要 */
  getStatus() {
    return {
      confidence: this.state.confidence,
      interactionCount: this.state.interactionCount,
      humanEscalations: this.state.humanEscalations,
      escalationRate: this.state.interactionCount > 0
        ? (this.state.humanEscalations / this.state.interactionCount).toFixed(2)
        : 0,
      topWeights: Object.entries(this.model.weights)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 3)
        .map(([k, v]) => ({ dimension: k, weight: v.toFixed(3) })),
    };
  }
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ConsumerAI;
}
